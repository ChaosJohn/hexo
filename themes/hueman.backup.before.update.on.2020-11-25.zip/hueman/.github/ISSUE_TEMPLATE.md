Please make sure these boxes are checked before submitting your issue. Thank you!

- [ ] I have inited and configurated the blog according to [Hexo official documentation](https://hexo.io/);
- [ ] I have read the [Theme Wiki](https://github.com/ppoffice/hexo-theme-hueman/wiki) carefully;
- [ ] I have looked up the [Issues](https://github.com/ppoffice/hexo-theme-hueman/issues) and found no duplicate issues.

